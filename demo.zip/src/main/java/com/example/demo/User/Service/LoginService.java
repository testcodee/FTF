package com.example.demo.User.Service;

import com.example.demo.User.Mapper.UserMapper;
import com.example.demo.User.Vo.User;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class LoginService {
    private final UserMapper userMapper;
    private final BCryptPasswordEncoder bCryptPasswordEncoder;

    public List<User> getUser(){
        return userMapper.getUsers();
    }

    public User login(String username, String rawPassword) {
        User user = userMapper.findByUserId(username);

        // 1. 아이디 없음
        if (user == null) {
            return null;
        }

        // 2. 비밀번호 불일치
        if (!bCryptPasswordEncoder.matches(rawPassword, user.getPassword())) {
            return null;
        }

        // 3. 로그인 성공
        return user;
    }
}
