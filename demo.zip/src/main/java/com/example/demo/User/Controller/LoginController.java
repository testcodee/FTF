package com.example.demo.User.Controller;

import com.example.demo.User.Service.LoginService;
import com.example.demo.User.Vo.User;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequiredArgsConstructor
public class LoginController {

    private final LoginService loginService;


    @GetMapping("/login")
    public String login(){
        return "login";
    }

    @PostMapping("/login")
    @ResponseBody
    public String login(@RequestBody User reqUser, HttpSession session) {

        User user = loginService.login(reqUser.getUserId(), reqUser.getPassword());

        if (user != null) {
            // 로그인 세션 저장
            session.setAttribute("loginUser", user);
            session.setMaxInactiveInterval(30 * 60);
            return "{\"message\" : \"success\"}";
        }
        

        return "{\"message\" : \"아이디 또는 비밀번호가 잘못되었습니다.\"}";
    }

    @RequestMapping("/logout")
    public String logout(HttpSession session) {
        session.removeAttribute("loginUser");
        session.invalidate();
        return "redirect:/login";
    }

}
