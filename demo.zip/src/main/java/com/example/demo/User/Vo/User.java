package com.example.demo.User.Vo;

import lombok.*;

@Data
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class User {
    private int id;
    private String userId;
    private String userName;
    private String password;
}
