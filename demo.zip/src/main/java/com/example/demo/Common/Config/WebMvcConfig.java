package com.example.demo.Common.Config;

import com.example.demo.Common.Interceptor.LoginCheckInterceptor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebMvcConfig implements WebMvcConfigurer {

    @Override
    public void addInterceptors(InterceptorRegistry registry){
        registry.addInterceptor(new LoginCheckInterceptor())
                .addPathPatterns("/**")                        // 모든 요청 체크
                .excludePathPatterns(
                        "/login", "/login/**",                // 로그인 페이지
                        "/loginProc",                         // 로그인 처리
                        "/logout",                            // 로그아웃
                        "/css/**", "/js/**", "/images/**",    // 정적 리소스
                        "/error"                              // 에러 페이지
                );
    }
}
