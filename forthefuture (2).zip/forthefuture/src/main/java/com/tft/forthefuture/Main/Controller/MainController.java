package com.tft.forthefuture.Main.Controller;

import com.tft.forthefuture.User.Vo.User;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.Arrays;
import java.util.List;

@Controller
public class MainController {
    @GetMapping("/")
    public String Main(){
        return "/user/login";
    }

    @GetMapping("/main")
    public String main(HttpSession session, Model model){

        User user = (User) session.getAttribute("loggedInUser"); // 로그인 시 세션에 저장한 키 (loggedInUser)
        if (user == null) {
            return "redirect:/user/login"; // 세션 없으면 로그인으로 리다이렉트
        }

        model.addAttribute("user", user); // 로그인된 사용자 정보 전달

        // ------ Mock Data 생성 시작 ------
        // 1. 총 자산 현황 섹션용 Mock Data
        model.addAttribute("totalAssets", "123,456,789"); // 예시: 총 자산
        model.addAttribute("monthlyIncome", "5,000,000"); // 예시: 이번 달 수입
        model.addAttribute("monthlyExpense", "3,200,000"); // 예시: 이번 달 지출

        // 2. 재정 목표 진행 현황 섹션용 Mock Data (예시)
        model.addAttribute("goalName", "내 집 마련 플랜");
        model.addAttribute("goalAchievedAmount", "210,000,000");
        model.addAttribute("goalTargetAmount", "300,000,000");
        model.addAttribute("goalProgressPercentage", 70); // 70% 달성

        // 3. 섹션 아이템 리스트 Mock Data (이전 HTML에서 사용했던 부분)
        List<String> section1Items = Arrays.asList("총자산", "수입", "지출");
        List<String> section2Items = Arrays.asList("목표1", "목표2", "목표3");
        List<String> section3Items = Arrays.asList("빠른입력", "조회", "설정");

        model.addAttribute("section1Items", section1Items);
        model.addAttribute("section2Items", section2Items);
        model.addAttribute("section3Items", section3Items);
        // ------ Mock Data 생성 끝 ------

        return "main"; // templates/main.html 렌더링
    }

}
