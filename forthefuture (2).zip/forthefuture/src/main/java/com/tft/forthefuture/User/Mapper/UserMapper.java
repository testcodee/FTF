package com.tft.forthefuture.User.Mapper;

import com.tft.forthefuture.User.Vo.User;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UserMapper {
    User selectUser(Long userId);
}
