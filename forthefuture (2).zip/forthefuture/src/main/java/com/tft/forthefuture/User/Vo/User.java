package com.tft.forthefuture.User.Vo;

import lombok.Data; // @Data 어노테이션을 사용하기 위한 임포트
import lombok.NoArgsConstructor; // 기본 생성자를 자동으로 만들어주는 어노테이션
import lombok.AllArgsConstructor; // 모든 필드를 인자로 받는 생성자를 자동으로 만들어주는 어노테이션
import java.time.LocalDateTime; // TIMESTAMP 타입을 매핑하기 위한 임포트
import java.io.Serializable; // VO가 직렬화 가능하도록 선언 (선택적이지만 일반적으로 권장)

@Data // @Getter, @Setter, @ToString, @EqualsAndHashCode, @RequiredArgsConstructor를 한 번에 추가해줍니다.
@NoArgsConstructor // 파라미터가 없는 기본 생성자를 자동으로 생성합니다.
@AllArgsConstructor // 모든 필드를 파라미터로 받는 생성자를 자동으로 생성합니다.
public class User implements Serializable { // Serializable 인터페이스 구현은 선택사항이지만, 객체를 직렬화해야 하는 경우 (예: 세션 저장, 캐싱 등)에 유용합니다.

    // id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '사용자 고유 식별자'
    private Long id;

    // username VARCHAR(50) NOT NULL UNIQUE COMMENT '로그인 아이디'
    private String username;

    // password VARCHAR(255) NOT NULL COMMENT '해시된 비밀번호'
    private String password;

    // name VARCHAR(100) NOT NULL COMMENT '사용자 이름 또는 별명'
    private String name;

    // email VARCHAR(100) UNIQUE COMMENT '이메일 주소 (비밀번호 찾기, 인증 등)'
    private String email;

    // created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '사용자 계정 생성 일시'
    // 데이터베이스의 TIMESTAMP는 Java의 LocalDateTime과 잘 매핑됩니다.
    private LocalDateTime createdAt;

    // updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '사용자 정보 마지막 수정 일시'
    // 데이터베이스의 TIMESTAMP는 Java의 LocalDateTime과 잘 매핑됩니다.
    private LocalDateTime updatedAt;
}
