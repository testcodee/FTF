package com.tft.forthefuture.Main.Controller;

import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MainController {
    @GetMapping("/")
    public String Main(){
        return "login";
    }

    @GetMapping("/main")
    public String main(HttpSession session, Model model){
        Object user = session.getAttribute("loggedInUser");
        if (user == null) {
            // 세션에 사용자 정보가 없으면 로그인 페이지로 리다이렉트
            return "redirect:/login";
        }
        model.addAttribute("user", user);
        return "main";
    }

}
