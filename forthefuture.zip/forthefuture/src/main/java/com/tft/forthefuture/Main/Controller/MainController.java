package com.tft.forthefuture.Main.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MainController {
    @GetMapping("/")
    public String Main(){
        return "login";
    }

    @GetMapping("/main")
    public String main(){
        return "main";
    }

}
