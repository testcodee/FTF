package com.example.demo.User.Controller;

import com.example.demo.User.Service.LoginService;
import com.example.demo.User.Vo.User;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
@RequiredArgsConstructor
public class LoginController {

    private final LoginService loginService;

    @PostMapping("/login")
    @ResponseBody
    public String login(@RequestBody User reqUser, Model model, HttpSession session) {

        User user = loginService.login(reqUser.getUserId(), reqUser.getPassword());

        if (user == null) {
            model.addAttribute("error", "아이디 또는 비밀번호가 잘못되었습니다.");
            return "login";
        }
        
        // 로그인 세션 저장
        session.setAttribute("loginUser", user);
        // 로그인 성공 → 메인 화면 이동
        model.addAttribute("user", user);
        return "redirect:/home";
    }

}
